SCREEN is a reconstruction method for general sparse sampling NMR spectroscopy including Fourier and Laplace NMR.
The code of SCREEN is programmed in Matlab. The core optimization algorithm is served as TNIPM[1] (i.e., l1_ls_nonneg and  l1_ls function)
If you use this code please cite the paper related to SCREEN and the other invovled papers.

1.0 version, Oct 11 2021
Author : Enping Lin  <646332908@qq.com>

[1], Koh, K.; Lustig, M.; Gorinevsky, S. B. D., An Interior-Point Method for Large-Scale L1-Regularized Least Squares. IEEE Journal of Selected Topics in Signal Processing 2008, 1 (4), 606-617.